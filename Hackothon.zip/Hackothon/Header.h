
#define _CRT_SECURE_NO_WARNINGS

#define BLUE "\x1b[34;44m" 

#define YELLOW "\x1b[33;43m"

#define WHITE "\x1b[37;47m"

#define LIGHTBLUE "\x1b[36;46m"

#define PURPLE "\x1b[35;45m"

#define RED "\x1b[31;41m"

#define GREEN "\x1b[32;42m"

#define BLACK "\x1b[30;40m"

#define RESET "\x1b[0m" 


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <conio.h>


typedef struct cell {
	int X;
	int Y;
	char symbol;
}Cell;

//FUNC
int get_arrow_input();
int printMenu();
void printInstructions();

//SHAPES
void shapes(Cell board[][75]);
void make_circle(Cell canvas[][75], int radius, Cell center, char newsymbol);
void rectangle(Cell board[][75]);
void square(Cell board[][75]);

//DISPLAY
void print_board(Cell array[][75]);
void initial_board(Cell array[][75], char symbol);
Cell move_around_canvas(Cell canvas[][75]);

//MATH


