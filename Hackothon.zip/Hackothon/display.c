#include "Header.h"

void initial_board(Cell array[][75], char symbol) {

	//move row count
	for (int i = 0; i < 50; i++)
	{
		//move column count
		for (int j = 0; j < 75; j++)
		{
			array[i][j].symbol = symbol;
			array[i][j].X = i;
			array[i][j].Y = j;
		}
	}
}


void print_board(Cell array[][75])
{
	printf("-------------------------------------------------------------------------------------------------------\n");

	for (int i = 0; i < 50; i++)
	{
		printf("%-2d ", i);
		for (int j = 0; j < 75; j++)
		{
			printf("%-2c", array[i][j].symbol);
		}
		putchar('\n');
	}
	printf("-------------------------------------------------------------------------------------------------------\n");
}
