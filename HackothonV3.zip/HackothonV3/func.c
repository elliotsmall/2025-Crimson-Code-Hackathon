#include "Header.h"

int printMenu()
{
	char* message1 = "Welcome to the";
	char* message2 = RED1 "IMAGINATION STATION\n" RESET;
	char* message3 = GREEN1 "1. USER MANUAL\n" RESET;
	char* message4 = BLUE1 "2. OPEN CANVAS\n" RESET;
	char* message5 = YELLOW1 "3. EXIT\n" RESET;
	char* message6 = "Please Enter Your Selection: ";
	int option = 0;
	do {
	system("cls");
	printf("%100s %s", message1, message2);
	printf("%120s\n", message3);
	printf("%120s\n", message4);
	printf("%115s\n", message5);
	printf("%110s", message6);
		scanf("%d", &option);
		if (option == 1) {
			system("cls");
			printInstructions();
			system("pause");
		}
	} while (option > 3 || option < 0);

	return option;
}

void printInstructions()
{
	printf("Welcome to IMAGINAITON STATION, your new FAVORITE command line art canvas!\n");
	printf("To draw on the canvas, you can move your cursor around, by using the W, A, S, and D keys.\n");
	printf("The inputs go as follows:\nW = Up\nA = Left\nS = Down\nD = Right\nQ = Exit\nP = Place\n");
	printf("Once you select a cell to color, you will be given a prompt to enter a color\n");
	printf("You also have the option to insert either a circle, square/rectangle, or triangle\n");
	printf("If selected, you will have be able to choose a center point, and dimensions of your shape\n");
	printf("After selecting the center and size, you will also be asked to choose a color\n");

	system("pause");
	system("cls");
}

Marker setMarker()
{
	Marker newMarker;
	printf("Enter new symbol: ");
	getchar();
	scanf("%c", &newMarker.symbol);
	printf("Enter new color:");
	getchar();
	scanf("%d", &newMarker.color);

	return newMarker;
}

int get_arrow_input()
{
	//printf("Press an WASD key to move and P to place (use Q to exit):\n");
	//initilize input
	char input = '\0';

	//Get and verify user input
	do{
		input = _getch();
	} while (input != 'w' && input != 'W' && input != 'a' && input != 'A' && input != 's' && input != 'S' && input != 'd' && input != 'D' && input != 'Q' && input != 'q' && input != 'P' && input != 'p' && input != 'm' && input != 'M');
	
	//return a direction int
	if (input == 'Q' || input == 'q') {
		return 0;
	}
	else if (input == 'w' || input == 'W') {
		return 1;
	}
	else if (input == 's' || input == 'S') {
		return 2;
	}
	else if (input == 'd' || input == 'D') {
		return 3;
	}
	else if (input == 'a' || input == 'A') {
		return 4;
	}
	else if (input == 'p' || input == 'P') {
		return 5;
	}
	else if (input == 'm' || input == 'M') {
		return 6;
	}
}

Cell move_around_canvas(Cell canvas[][75], Marker *currentMarker) {
	int arrow = 0;
	char* temp = '\0';
	Cell cursor = { 0,0,'+' };
	do {
		temp = canvas[cursor.X][cursor.Y].symbol;
		canvas[cursor.X][cursor.Y].symbol = '+';
		print_board(canvas);
		canvas[cursor.X][cursor.Y].symbol = temp;
		arrow = get_arrow_input();
		if (arrow == 1) {
			cursor.X--;
		}
		else if (arrow == 2) {
			cursor.X++;
		}
		else if (arrow == 3) {
			cursor.Y++;
		}
		else if (arrow == 4) {
			cursor.Y--;
		}
		else if (arrow == 6)
		{
			*currentMarker = setMarker();
		}
		system("cls");
		if (cursor.X < 0) {
			cursor.X = 0;
		}
		if (cursor.X > 49){
			cursor.X = 49;
		}
		if(cursor.Y < 0) {
			cursor.Y = 0;
		}
		if (cursor.Y > 74){
			cursor.Y = 74;
		}
	} while (arrow != 0 && arrow != 5);

	return cursor;
}

