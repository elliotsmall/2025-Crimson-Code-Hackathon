#include "Header.h"

int shapes(Cell board[][75], Marker currentMarker)
{
	char x = '\0';
	
	char symbol = '\0';

	int shape = 0;

	printf("Would you like to add a pre-determined shape? (Y/N) ");

	scanf(" %c", &x);
	getchar();
	if (x == 'Y' || x == 'y')
	{
		printf("what shape would you like to make?\n");
		printf("1. Rectangle\n");
		printf("2. Circle\n");
		printf("3. Triangle\n");

		do {
			scanf("%d", &shape);
		} while (shape < 0 || shape > 3);

		if (shape == 1) {
			rectangle(board, currentMarker);
		}
		else if (shape == 3) {
			int height = 0, width = 0;
			Cell center = move_around_canvas(board, &currentMarker);
			printf("Enter a height: ");
			do
			{
				scanf("%d", &height);
			} while (height < 0);
			printf("Enter a width: ");
			do
			{
				scanf("%d", &width);
			} while (width < 0);
			drawTriangle(center, height, width, currentMarker, board);
		}
		else if (shape == 2) {
			int radius = 0;
			Cell cursor = move_around_canvas(board, &currentMarker);
			printf("\nEnter a radius: ");
			do {
				scanf("%d", &radius);
			} while (radius < 0);
			make_circle(board, radius, cursor, currentMarker);
		}
	}
	else if (x == 'N' || x == 'n')
	{
		return 0;
	}
	return 1;
}

void rectangle(Cell board[][75], Marker currentMarker)
{
	char array[30];

	char symbol = '\0';

	int length = 0, width = 0, center = 0, pointX = 0, pointY = 0;

	printf("Enter length:");

	scanf("%d", &length);

	printf("Enter width:");

	scanf("%d", &width);

	printf("Choose the symbol:");

	scanf(" %c", &symbol);

	printf("Pick a point on the board to place the shape:\n");

	Cell cursor = move_around_canvas(board, &currentMarker);
	pointX = cursor.X;
	pointY = cursor.Y;

	center = length / 2;

	for (int i = 0; i < length; i++)
	{
		if (pointY + i > 74 || pointX > 74)
		{
			break;
		}
		board[pointX][pointY + i].symbol = currentMarker.symbol;
		board[pointX][pointY + i].color = currentMarker.color;

	}

	for (int j = 0; j < width; j++)
	{
		if (pointY > 74 || pointX + j > 74)
		{
			break;
		}
		board[pointX + j][pointY].symbol = currentMarker.symbol;
		board[pointX + j][pointY].color = currentMarker.color;
	}

	for (int z = 0; z < length; z++)
	{
		if (pointY + z > 74 || pointX + width - 1 > 74)
		{
			break;
		}
		board[pointX + width - 1][pointY + z].symbol = currentMarker.symbol;
		board[pointX + width - 1][pointY + z].color = currentMarker.color;

	}

	for (int j = 0; j < width; j++)
	{
		if (pointY + length - 1 > 74 || pointX + j > 74)
		{
			break;
		}
		board[pointX + j][pointY + length - 1].symbol = currentMarker.symbol;
		board[pointX + j][pointY + length - 1].color = currentMarker.color;
	}
}

void square(Cell board[][75], Marker currentMarker)
{
	char array[30];

	int length = 0, centerLength = 0, pointX = 0, pointY = 0;

	printf("Enter length and Width:");

	scanf("%d", &length);

	printf("Pick a point on the board to place the shape: (x,y)\n");

	scanf("%d", &pointX);
	scanf("%d", &pointY);

	int center = length / 2;

	for (int i = -center; i <= center; i++) {

		for (int j = -center; j <= center; j++)
		{
			int x = pointX + i;

			int y = pointY + j;

			if (x >= 0 && x < 74 && y >= 0 && y < 74) {

				if (i == -center || i == center || j == -center || j == center)
				{

					board[x][y].symbol = currentMarker.symbol;
					board[x][y].color = currentMarker.color;
				}

			}
		}
	}
}

void make_circle(Cell canvas[][75], int radius, Cell center, Marker currentMarker) {

	int decision = 0;

	decision = 3 - (2 * radius);

	Cell circle = { 0, radius, '\0' };

	while (circle.X <= circle.Y) {

		if (center.X + circle.Y < 75 && center.Y + circle.X < 75)
			canvas[center.X + circle.Y][center.Y + circle.X].symbol = currentMarker.symbol;
			canvas[center.X + circle.Y][center.Y + circle.X].color = currentMarker.color;
		if (center.X + circle.X < 75 && center.Y + circle.Y < 75)
			canvas[center.X + circle.X][center.Y + circle.Y].symbol = currentMarker.symbol;
			canvas[center.X + circle.X][center.Y + circle.Y].color = currentMarker.color;
		if (center.X - circle.X >= 0 && center.Y + circle.Y < 75)
			canvas[center.X - circle.X][center.Y + circle.Y].symbol = currentMarker.symbol;
			canvas[center.X - circle.X][center.Y + circle.Y].color = currentMarker.color;
		if (center.X - circle.Y >= 0 && center.Y + circle.X < 75)
			canvas[center.X - circle.Y][center.Y + circle.X].symbol = currentMarker.symbol;
			canvas[center.X - circle.Y][center.Y + circle.X].color = currentMarker.color;
		if (center.X - circle.Y >= 0 && center.Y - circle.X >= 0)
			canvas[center.X - circle.Y][center.Y - circle.X].symbol = currentMarker.symbol;
			canvas[center.X - circle.Y][center.Y - circle.X].color = currentMarker.color;
		if (center.X - circle.X >= 0 && center.Y - circle.Y >= 0)
			canvas[center.X - circle.X][center.Y - circle.Y].symbol = currentMarker.symbol;
			canvas[center.X - circle.X][center.Y - circle.Y].color = currentMarker.color;	
		if (center.X + circle.X < 75 && center.Y - circle.Y >= 0)
			canvas[center.X + circle.X][center.Y - circle.Y].symbol = currentMarker.symbol;
			canvas[center.X + circle.X][center.Y - circle.Y].color = currentMarker.color;
		if (center.X + circle.Y < 75 && center.Y - circle.X >= 0)
			canvas[center.X + circle.Y][center.Y - circle.X].symbol = currentMarker.symbol;
			canvas[center.X + circle.Y][center.Y - circle.X].color = currentMarker.color;	

		if (decision < 0) {
			decision = decision + 4 * circle.X + 6;
			circle.X++;
		}
		else {
			decision = decision + 4 * (circle.X - circle.Y) + 10;
			circle.X++;
			circle.Y--;
		}
	}
}

void drawTriangle(Cell center, int height, int width, Marker currentMarker, Cell board[][75])
{
	int point1X = 0, point1Y = 0, point2X = 0, point2Y = 0, point3X = 0, point3Y = 0; //these represent three points of the triangle

	point1X = center.X;
	point1Y = center.Y + height / 2;

	point2X = center.X - width / 2;
	point2Y = center.Y - height / 2;

	point3X = center.X + width / 2;
	point3Y = center.Y - height / 2;

	drawLine(point1X, point1Y, point2X, point2Y, currentMarker, board);
	drawLine(point2X, point2Y, point3X, point3Y, currentMarker, board);
	drawLine(point3X, point3Y, point1X, point1Y, currentMarker, board);
}

void drawLine(int x0, int y0, int x1, int y1, Marker currentMarker, Cell board[][75])
{
	int dx = abs(x1 - x0);
	int dy = abs(y1 - y0); //absolute values of the change of x and y
	int sx = (x0 < x1) ? 1 : -1; //determines direction for x
	int sy = (y0 < y1) ? 1 : -1; //determines direction for y
	int err = dx - dy;

	while (1) //infinite loop, will be broken later in the loop
	{
		if (x0 >= 0 && x0 < 75 && y0 >= 0 && y0 < 50)
		{
			board[y0][x0].symbol = currentMarker.symbol;
			board[y0][x0].color = currentMarker.color;
		}
		if (x0 == x1 && y0 == y1)
		{
			break; //breaks loop because endpoint has been reached
		}
		int e2 = 2 * err; //Double error value

		if (e2 > -dy)  // Move in x direction if needed
		{
			err -= dy;
			x0 += sx;
		}
		if (e2 < dx) // Move in y direction if needed
		{
			err += dx;
			y0 += sy;
		}
	}
}
