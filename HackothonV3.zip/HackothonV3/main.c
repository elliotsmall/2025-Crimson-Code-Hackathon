#include "Header.h"

int main(void)
{
	Cell cursor = { 0, 0 ,'0' };
	Cell canvas[50][75];
	
	initial_board(canvas, '.');
	int choice = 0;
	int breakOut = 0;
	choice = printMenu();
	while (choice != 3) {
		print_board(canvas);
		breakOut = shapes(canvas);
		if (!breakOut)
		{
			return 0;
		}
	}
	return 0;
}